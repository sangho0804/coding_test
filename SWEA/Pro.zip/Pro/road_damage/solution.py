import heapq

INF = 1e8
graph = []
info  = {}

class Node:
	def __init__(self, city):
		self.city = city
		self.roads = []

class Road:
	def __init__(self, mId, nextCity, mTime):
		self.mId = mId
		self.nextCity = nextCity
		self.mTime = mTime

def init(N, K, mId, sCity, eCity, mTime):

	# init(n, k, mIdArr, sCityArr, eCityArr, mTimeArr)
	# n = city { 0 ~ N-1 }
	# k = road {number of k road : 0 id , 1 start, 2 end, 3 time }
	
	global graph, info
	graph = [Node(i) for i in range(N)]
	info = {}

	for i in range(K):
		road = Road(mId[i], eCity[i], mTime[i])
		graph[sCity[i]].roads.append(road)
		info[mId[i]] = (sCity[i], road)

	return


def add(mId, sCity, eCity, mTime):
	global graph, info

	road = Road(mId, eCity, mTime)
	graph[sCity].roads.append(road)
	info[mId] = (sCity, road)

	return


def remove(mId):

	sCity, road = info[mId]
	graph[sCity].roads.remove(road)
	del info[mId]
	 
	return
	
def dijkstra(sCity, eCity, blocked_id=-1):
	times = [INF for _ in range(len(graph))]
	times[sCity] = 0

	pq = [(0, sCity, [])]  # time, city, path

	while pq:
		time, loc, path = heapq.heappop(pq)

		if time > times[loc]:
			continue

		if loc == eCity :
			return time, path

		for road in graph[loc].roads:

			if road.mId == blocked_id:
				continue

			next_city = road.nextCity
			next_time = time + road.mTime

			if next_time < times[next_city]:
				times[next_city] = next_time

				heapq.heappush(pq, (next_time, next_city, path + [road.mId]))

	return -1, []

def calculate(sCity, eCity):


	original_time, short_path = dijkstra(sCity, eCity)
	# print(original_time)

	if original_time == -1:
		return -1

	max_time = 0

	for road_id in short_path:

		new_time, _ = dijkstra(sCity, eCity, road_id)

		if new_time == -1:
			return -1

		max_time = max(max_time, new_time)
	
	#print(max_time)
	return max_time - original_time 